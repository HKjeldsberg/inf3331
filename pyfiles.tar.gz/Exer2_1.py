import random

s = random.uniform(-1,1)
print "You number is: %.4f" % s
