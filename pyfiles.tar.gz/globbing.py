import glob

files = glob.glob('*.py')
print files
